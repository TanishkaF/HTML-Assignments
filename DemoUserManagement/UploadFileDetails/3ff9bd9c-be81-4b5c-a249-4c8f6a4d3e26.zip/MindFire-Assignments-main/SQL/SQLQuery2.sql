SELECT TOP (1000) [DepartmentID]
      ,[Name]
      ,[GroupName]
      ,[ModifiedDate]
  FROM [AdventureWorks2022].[HumanResources].[Department]

 use AdventureWorks2022

 select * from [HumanResources].[Department]

 

